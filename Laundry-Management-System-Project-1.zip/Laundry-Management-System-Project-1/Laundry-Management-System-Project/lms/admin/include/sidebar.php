<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Reg Users</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                    <a class="dropdown-item" href="user-detail.php">Reg Users</a>
          
          
        </div>
      </li>
   
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Laundry Requests</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <a class="dropdown-item" href="new-request.php">New Requests</a>
        <a class="dropdown-item" href="accept-request.php">Accept Requests</a>
          <a class="dropdown-item" href="inprocess-request.php">Inprocess Requests</a>
          <a class="dropdown-item" href="finish-request.php">Finish Requests</a>
          <a class="dropdown-item" href="all-requests.php">All Requests</a>
          
        </div>
      </li>
       <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Manage Laundry Price</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                    <a class="dropdown-item" href="manage-laundryprice.php">Laundry Price</a>
          
          
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Reports</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <a class="dropdown-item" href="bwdates-report-ds.php">B/w Dates</a>
          <a class="dropdown-item" href="requestcount-report-ds.php">Requests Count</a>
          
          
        </div>
      </li>
    </ul>
