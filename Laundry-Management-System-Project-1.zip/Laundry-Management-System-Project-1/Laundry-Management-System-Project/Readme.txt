How to run the Laundry management System  Project

1. Download the  zip file
2. Extract the file and copy lms folder
3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with name lmsdb
6. Import lmsdb.sql file(given inside the zip package in sql file folder)
7.Run the script http://localhost/lms (frontend)
8. For admin panel http://localhost/lms/admin  (admin panel)
Credential for admin panel :
Username: admin
Password: Test@123

Credential for user panel :
Username: amitk@test.com
Password: Test@123
Or Register a new user
